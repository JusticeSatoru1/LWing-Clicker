from PIL import Image, ImageTk
import customtkinter as ctk
from tkinter import Canvas, Label
from pynput.mouse import Button, Controller
import threading
import time
import os
import webbrowser

class AutoClickerApp:

    def __init__(self, root):
        self.root = root
        self.root.title('AutoClicker')
        self.root.geometry('640x360')
        self.root.resizable(False, False)
        base_dir = os.path.dirname(__file__)
        image_path = os.path.join(base_dir, 'ClickerGUI', 'background.png')
        self.canvas = Canvas(root, width=640, height=360)
        self.canvas.pack(fill='both', expand=True)
        self.mouse = Controller()
        self.click_type = Button.left
        self.cps = 0
        self.is_clicking = False
        self.is_hold_clicker = False
        self.is_instant_clicker = False
        self.key_activated = False
        self.default_clicker_key = '/'
        self.clicker_key = self.default_clicker_key
        self.load_background(image_path)
        self.left_button = ctk.CTkButton(root, text='Left Click', command=self.set_left_click, width=100, height=100)
        self.left_button.place(x=180, y=100)
        self.right_button = ctk.CTkButton(root, text='Right Click', command=self.set_right_click, width=100, height=100)
        self.right_button.place(x=360, y=100)
        self.slider = ctk.CTkSlider(root, from_=0, to=50, command=self.update_cps)
        self.slider.place(x=180, y=230)
        self.cps_label = ctk.CTkLabel(root, text='CPS: 0')
        self.cps_label.place(x=360, y=260)
        self.key_entry = ctk.CTkEntry(root, placeholder_text='Press key to activate clicker')
        self.key_entry.place(x=180, y=300)
        self.key_entry.bind('<KeyRelease>', self.set_clicker_key)
        self.clicker_mode_var = ctk.StringVar(value='none')
        self.hold_clicker_radio = ctk.CTkRadioButton(root, text='Hold Key for Clicker', variable=self.clicker_mode_var, value='hold', command=self.update_clicker_mode)
        self.hold_clicker_radio.place(x=180, y=340)
        self.instant_clicker_radio = ctk.CTkRadioButton(root, text='Instant Clicker', variable=self.clicker_mode_var, value='instant', command=self.update_clicker_mode)
        self.instant_clicker_radio.place(x=360, y=340)
        self.add_custom_text()
        self.thread = threading.Thread(target=self.click_loop)
        self.thread.daemon = True
        self.thread.start()

    def load_background(self, image_path):
        try:
            image = Image.open(image_path)
            image = image.resize((640, 360), Image.Resampling.LANCZOS)
            self.background_image = ImageTk.PhotoImage(image)
            self.canvas.create_image(0, 0, anchor='nw', image=self.background_image)
        except Exception as e:
            print(f'Error loading image: {e}')
        else:
            pass

    def set_left_click(self):
        self.click_type = Button.left
        self.update_click_type_visuals()

    def set_right_click(self):
        self.click_type = Button.right
        self.update_click_type_visuals()

    def update_click_type_visuals(self):
        if self.click_type == Button.left:
            self.left_button.configure(fg_color='blue')
            self.right_button.configure(fg_color='white')
        else:
            self.left_button.configure(fg_color='white')
            self.right_button.configure(fg_color='blue')

    def update_cps(self, value):
        self.cps = int(float(value))
        self.cps_label.configure(text=f'CPS: {self.cps}')

    def set_clicker_key(self, event):
        new_key = event.keysym.lower()
        if new_key and new_key != self.default_clicker_key:
            self.clicker_key = new_key
            print(f'Clicker key changed to: {self.clicker_key}')

    def update_clicker_mode(self):
        mode = self.clicker_mode_var.get()
        if mode == 'hold':
            self.is_hold_clicker = True
            self.is_instant_clicker = False
        elif mode == 'instant':
            self.is_hold_clicker = False
            self.is_instant_clicker = True
        else:
            self.is_hold_clicker = False
            self.is_instant_clicker = False

    def add_custom_text(self):
        made_by_label = Label(self.root, text='Made By Justice Satoru', font=('Arial', 10, 'italic'), fg='yellow', bg='black')
        made_by_label.place(x=500, y=10)
        discord_label = Label(self.root, text='Discord: mathsucks39', font=('Arial', 10, 'italic'), fg='yellow', bg='black')
        discord_label.place(x=500, y=30)


        # Added red "YT Link" text and link functionality
        yt_link_label = Label(self.root, text='YT Link', font=('Arial', 10, 'italic'), fg='red', bg='black', cursor="hand2")
        yt_link_label.place(x=500, y=50)
        yt_link_label.bind("<Button-1>", self.open_youtube)

    def open_youtube(self, event):
        webbrowser.open("https://www.youtube.com/@JusticeSatoruTut")

    def click_loop(self):
        from pynput import keyboard

        def on_press(key):
            try:
                if key.char == self.clicker_key:
                    self.key_activated = True
                    if self.is_instant_clicker:
                        self.is_clicking = not self.is_clicking
            except AttributeError:
                return None
            else:
                pass

        def on_release(key):
            try:
                if key.char == self.clicker_key:
                    self.key_activated = False
                    if self.is_hold_clicker:
                        self.is_clicking = False
            except AttributeError:
                return None
            else:
                pass
        with keyboard.Listener(on_press=on_press, on_release=on_release) as listener:
            while True:
                if self.is_hold_clicker and self.key_activated:
                    self.mouse.click(self.click_type)
                    time.sleep(1 / self.cps)
                elif self.is_instant_clicker and self.is_clicking:
                    self.mouse.click(self.click_type)
                    time.sleep(1 / self.cps)
                else:
                    time.sleep(0.01)
        return None
if __name__ == '__main__':
    root = ctk.CTk()
    app = AutoClickerApp(root)
    root.mainloop()
